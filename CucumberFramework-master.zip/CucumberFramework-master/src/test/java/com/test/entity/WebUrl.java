package com.test.entity;

public class WebUrl {
	
	String target_url;

	public String getTarget_url() {
		return target_url;
	}

	public void setTarget_url(String target_url) {
		this.target_url = target_url;
	}
	
}
